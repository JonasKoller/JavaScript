$('.number').on('click', function() {
  calc.input.value += this.value;
});

$('.operator').on('click', function() {
  calc.input.value += ' ' + this.value + ' ';
});

$('[name="equals"]').on('click', function() {
  calc.input.value = parseFloat(eval(calc.input.value).toFixed(6));
});

$('[name="clear"]').on('click', function() {
  calc.input.value = '';
});